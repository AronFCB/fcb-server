const WebSocket = require('ws');
const fs = require('fs');

const wss = new WebSocket.Server({ port: process.env.PORT || 8080 });

// Cargar datos de `data.json`
let data = {};
try {
  data = JSON.parse(fs.readFileSync('data.json', 'utf-8'));
} catch (err) {
  console.log('No se pudo cargar el archivo data.json:', err);
}

wss.on('connection', (ws) => {
  console.log('Cliente conectado');
  
  // Enviar la lista de servidores favoritos al nuevo cliente
  ws.send(JSON.stringify({
    message: '�Bienvenido al servidor WebSocket!',
    favorites: data.favorites || [],
    history: data.history || []
  }));

  // Recibir mensajes
  ws.on('message', (message) => {
    console.log(`Mensaje recibido: ${message}`);
    
    // Actualizar los servidores favoritos o historial
    try {
      const parsedMessage = JSON.parse(message);
      if (parsedMessage.addFavorite) {
        if (!data.favorites) {
          data.favorites = [];
        }
        data.favorites.push(parsedMessage.addFavorite);
        fs.writeFileSync('data.json', JSON.stringify(data, null, 2)); // Guardar cambios
      }

      if (parsedMessage.addHistory) {
        if (!data.history) {
          data.history = [];
        }
        data.history.push(parsedMessage.addHistory);
        fs.writeFileSync('data.json', JSON.stringify(data, null, 2)); // Guardar cambios
      }
    } catch (err) {
      console.log('Error al procesar el mensaje:', err);
    }
  });

  // Desconexi�n
  ws.on('close', () => {
    console.log('Cliente desconectado');
  });
});

console.log('Servidor WebSocket escuchando...');
